
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AO THEORY-EXACT: Phase Transport Law + Dual-Channel Decomposition (Φ) + Intent Pulses

This script implements precisely the theoretical frame described in the user's notes:
1) Constants & kernel:  Φ (golden ratio), κ = π² / (Φ ln 10).
2) Source dynamics:      x(t) = x₀ · C(t),   C(t) = C_noise(t) + C_intent(t).
3) Carrier phase:        Ψ(t) = exp(-κ · M(t)),  with  M(t) = ∫₀ᵗ x(τ) dτ.
4) Φ-driven split:       dM_harm = (1/Φ)·x(t),   dM_esc = (1/Φ²)·x(t).
5) Operator closure (phase vector law): d/dt ln Ψ(t) = -κ x(t).
6) Conservation over [0,T]: M(T) = M_harm(T) + M_esc(T)  (after normalization by M(T)).

Outputs:
- CSV with t, x(t), M(t), Ψ(t), M_harm, M_esc and their normalized shares.
- PNG figures for x(t) and Ψ(t), and for normalized balances.

Usage (optional CLI):
    python AO_theory_exact.py --T 10 --N 1000 --x0 0.015 --seed 0 \
        --intent "2.9:3.1:-0.6,6.9:7.1:-0.8"

Notes:
- No explicit colors/styles are set (per instruction).
- Noise is bounded and reproducible with --seed.
"""
import argparse
import math
import numpy as np
import matplotlib.pyplot as plt
import csv
from typing import List, Tuple

# -------------------------------
# 1) Constants & helper functions
# -------------------------------
PI = math.pi
PHI = (1 + math.sqrt(5)) / 2.0
LN10 = math.log(10.0)
KAPPA = (PI**2) / (PHI * LN10)  # exact phase-cost coefficient per theory

def make_time_grid(T: float, N: int) -> np.ndarray:
    t = np.linspace(0.0, T, N, dtype=float)
    # Guard against degenerate N
    if N < 2:
        raise ValueError("N must be >= 2")
    return t

def clamp(a: np.ndarray, lo: float, hi: float) -> np.ndarray:
    return np.minimum(np.maximum(a, lo), hi)

def parse_intent_spec(spec: str) -> List[Tuple[float,float,float]]:
    """
    Parse intent pulses specification of the form:
      "t0:t1:amp, t0:t1:amp, ..."
    Each triple adds a rectangular negative pulse C_intent += amp on (t0, t1).
    Example: "2.9:3.1:-0.6,6.9:7.1:-0.8"
    """
    if spec.strip() == "":
        return []
    out = []
    for chunk in spec.split(","):
        tok = chunk.strip().split(":")
        if len(tok) != 3:
            continue
        t0, t1, a = map(float, tok)
        out.append((t0, t1, a))
    return out

# -------------------------------
# 2) Build source x(t) = x0 * C(t)
# -------------------------------
def build_source(t: np.ndarray, x0: float, seed: int, noise_clip=(0.5, 1.5),
                 intent: List[Tuple[float,float,float]] = None,
                 c_clip=(0.1, 2.0)) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    rng = np.random.RandomState(seed)
    # Stochastic noise around 1 with modest variance
    c_noise = 1.0 + 0.3 * rng.randn(t.size)
    c_noise = clamp(c_noise, noise_clip[0], noise_clip[1])
    # Intent pulses (negative pulses suppress leakage)
    c_intent = np.zeros_like(t)
    if intent:
        for (t0, t1, a) in intent:
            mask = (t >= t0) & (t <= t1)
            c_intent[mask] += a
    # Total modulation C(t)
    c_total = c_noise + c_intent
    c_total = clamp(c_total, c_clip[0], c_clip[1])
    # Source
    x_t = x0 * c_total
    return x_t, c_noise, c_intent

# ----------------------------------------------
# 3) Integrals, carrier phase and Φ-decomposition
# ----------------------------------------------

import numpy as np

def cumtrapz_custom(y, x=None, axis=-1):
    """
    Minimal NumPy-only replacement for scipy.integrate.cumtrapz.

    Parameters
    ----------
    y : array_like
        Sampled values of the integrand.
    x : array_like or None
        Sample points corresponding to `y`. If None, unit spacing is assumed.
        If provided, must be 1-D and broadcastable along `axis` of `y`.
    axis : int
        Axis along which to integrate.

    Returns
    -------
    res : ndarray
        Cumulative integral along `axis` using the trapezoidal rule.
        The length along `axis` is (y.shape[axis] - 1), matching SciPy’s cumtrapz
        when `initial` is not used.
    """
    y = np.asanyarray(y)
    n = y.shape[axis]
    if n <= 1:
        # Return empty array with same shape except length-0 along axis
        shape = list(y.shape)
        shape[axis] = 0
        return np.empty(shape, dtype=np.result_type(y))

    # Slices to compute adjacent pairs along `axis`
    sl1 = [slice(None)] * y.ndim
    sl2 = [slice(None)] * y.ndim
    sl1[axis] = slice(1, None)
    sl2[axis] = slice(0, -1)

    # Midpoint heights for trapezoids
    mid = 0.5 * (y[tuple(sl1)] + y[tuple(sl2)])

    if x is None:
        # Unit spacing
        incr = mid
    else:
        x = np.asanyarray(x)
        # Compute spacing ∆x along axis; must align with `mid` shape
        dx = np.diff(x, axis=axis)
        incr = mid * dx

    # Cumulative sum of trapezoid areas
    res = np.cumsum(incr, axis=axis)
    return res


def integrate_time_series(t: np.ndarray, y: np.ndarray) -> np.ndarray:
    """Cumulative integral via trapezoidal rule; matches ∫₀ᵗ y(τ) dτ."""
    # Use np.cumtrapz but keep full length by prefixing 0

    area = np.concatenate([[0.0], cumtrapz_custom(y, t)])
    return area

def compute_core(t: np.ndarray, x_t: np.ndarray):
    # M(t) and Ψ(t)
    M_t = integrate_time_series(t, x_t)
    Psi_t = np.exp(-KAPPA * M_t)

    # Φ-split of flow
    dM_harm = (1.0/PHI)  * x_t
    dM_esc  = (1.0/(PHI**2)) * x_t
    M_harm  = integrate_time_series(t, dM_harm)
    M_esc   = integrate_time_series(t, dM_esc)

    # Normalized balances over horizon T: divide by M(T)
    MT = M_t[-1] if M_t[-1] != 0 else 1.0
    mort_tax_norm = M_t / MT
    harm_credit_norm = M_harm / MT
    ent_debit_norm = M_esc / MT

    # Operator-check: d/dt ln Ψ = -κ x(t) (numerical derivative)
    # Using central differences where possible
    lnPsi = np.log(Psi_t + 1e-300)
    d_lnPsi = np.gradient(lnPsi, t)
    transport_residual = d_lnPsi + KAPPA * x_t  # should be ~0

    return {
        "M_t": M_t,
        "Psi_t": Psi_t,
        "M_harm": M_harm,
        "M_esc": M_esc,
        "mort_tax_norm": mort_tax_norm,
        "harm_credit_norm": harm_credit_norm,
        "ent_debit_norm": ent_debit_norm,
        "d_lnPsi": d_lnPsi,
        "transport_residual": transport_residual,
    }

# -----------------
# 4) Visualization
# -----------------
def plot_series(t: np.ndarray, y: np.ndarray, title: str, path: str, xlabel="t", ylabel=""):
    plt.figure()
    plt.plot(t, y)
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.tight_layout()
    plt.savefig(path, dpi=160)
    plt.close()

# ---------------
# 5) Save to CSV
# ---------------
def save_csv(path: str, t: np.ndarray, x_t: np.ndarray, core: dict):
    headers = [
        "t","x_t","M_t","Psi_t",
        "M_harm","M_esc",
        "MortalityTax_norm","HarmonicCredit_norm","EntropicDebit_norm",
        "d_dt_ln_Psi","transport_residual"
    ]
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(headers)
        for i in range(t.size):
            w.writerow([
                f"{t[i]:.12g}", f"{x_t[i]:.12g}", f"{core['M_t'][i]:.12g}", f"{core['Psi_t'][i]:.12g}",
                f"{core['M_harm'][i]:.12g}", f"{core['M_esc'][i]:.12g}",
                f"{core['mort_tax_norm'][i]:.12g}", f"{core['harm_credit_norm'][i]:.12g}", f"{core['ent_debit_norm'][i]:.12g}",
                f"{core['d_lnPsi'][i]:.12g}", f"{core['transport_residual'][i]:.12g}",
            ])

# ---------------
# 6) CLI / main
# ---------------
def main():
    p = argparse.ArgumentParser()
    p.add_argument("--T", type=float, default=10.0, help="Simulation horizon")
    p.add_argument("--N", type=int, default=1000, help="Number of time steps")
    p.add_argument("--x0", type=float, default=0.015, help="Base leakage scale x0")
    p.add_argument("--seed", type=int, default=0, help="Noise seed")
    p.add_argument("--intent", type=str, default="2.8:3.2:-0.6,6.8:7.2:-0.8",
                   help='Rectangular pulses "t0:t1:amp" comma-separated (negative amp suppresses leakage)')
    p.add_argument("--out_prefix", type=str, default="AO_theory_exact", help="Output file prefix")
    args = p.parse_args()

    t = make_time_grid(args.T, args.N)
    intents = parse_intent_spec(args.intent)
    x_t, c_noise, c_intent = build_source(t, args.x0, args.seed, intent=intents)

    core = compute_core(t, x_t)

    # Save CSV
    csv_path = f"./Results/{args.out_prefix}.csv"
    save_csv(csv_path, t, x_t, core)

    # Plots (one chart per figure; no explicit colors)
    plot_series(t, x_t,      "AO: x(t) = x0 · C(t) (noise + intent)", f"./Results/{args.out_prefix}__x_t.png", ylabel="x(t)")
    plot_series(t, core["Psi_t"], "AO: Ψ(t) = exp(-κ · M(t))",          f"./Results/{args.out_prefix}__Psi_t.png", ylabel="Ψ(t)")
    plot_series(t, core["mort_tax_norm"], "AO: M(T) balance — mortality tax (normalized)", f"./Results/{args.out_prefix}__mortality_norm.png", ylabel="M/M(T)")
    plot_series(t, core["harm_credit_norm"], "AO: harmonic credit (normalized)", f"./Results/{args.out_prefix}__harmonic_norm.png", ylabel="M_harm/M(T)")
    plot_series(t, core["ent_debit_norm"], "AO: entropic debit (normalized)", f"./Results/{args.out_prefix}__entropic_norm.png", ylabel="M_esc/M(T)")
    plot_series(t, core["transport_residual"], "AO: transport residual d/dt lnΨ + κ x(t) (should ~ 0)", f"./Results/{args.out_prefix}__transport_residual.png", ylabel="residual")

    # Console summary
    MT = core["M_t"][-1]
    print("--- AO THEORY-EXACT SUMMARY ---")
    print(f"Φ = {PHI:.12f}, κ = π²/(Φ ln 10) = {KAPPA:.12f}")
    print(f"T = {args.T}, N = {args.N}, x0 = {args.x0}, seed = {args.seed}")
    print(f"M(T) = {MT:.12g}")
    print(f"Check (normalized at T): mort={core['mort_tax_norm'][-1]:.4f}, harm={core['harm_credit_norm'][-1]:.4f}, esc={core['ent_debit_norm'][-1]:.4f}")
    print(f"CSV -> {csv_path}")
    print("PNG ->",
          f"{args.out_prefix}__x_t.png,",
          f"{args.out_prefix}__Psi_t.png,",
          f"{args.out_prefix}__mortality_norm.png,",
          f"{args.out_prefix}__harmonic_norm.png,",
          f"{args.out_prefix}__entropic_norm.png,",
          f"{args.out_prefix}__transport_residual.png")

if __name__ == "__main__":
    main()
