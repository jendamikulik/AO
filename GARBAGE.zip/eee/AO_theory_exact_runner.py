# Pipeline: DIMACS CNF -> AO integral -> Chain rule (phase vector law) check
# - Loads available CNF files in /mnt/data
# - Parses DIMACS
# - Maps CNF metrics -> intent pulses
# - Integrates AO transport per theory (Ψ, M, Φ-split)
# - Classifies SAT/UNSAT from filename (uf = SAT, uuf = UNSAT)
# - Saves CSV + PNGs and shows a results table

import os, glob, hashlib, math
from pathlib import Path
import numpy as np
import pandas as pd
import importlib
import matplotlib.pyplot as plt

#from caas_jupyter_tools import display_dataframe_to_user

# Import theory core
AO = importlib.import_module("AO_theory_exact")

# ---------- Helpers ----------
def parse_dimacs(path):
    nvars = nclauses = 0
    clauses = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("c"):
                continue
            if line.startswith("p"):
                toks = line.split()
                if len(toks) >= 4:
                    nvars = int(toks[2]); nclauses = int(toks[3])
            else:
                toks = line.split()
                if toks and toks[-1] == "0":
                    toks = toks[:-1]
                if toks:
                    clauses.append([int(x) for x in toks])
    return nvars, nclauses, clauses

def cnf_metrics(nvars, nclauses, clauses):
    alpha = nclauses / max(1, nvars)
    lengths = [len(c) for c in clauses if len(c) > 0]
    mean_k = float(np.mean(lengths)) if lengths else 0.0
    frac_unit = float(np.mean([1 if len(c)==1 else 0 for c in clauses])) if clauses else 0.0
    counts = {}
    for c in clauses:
        for lit in c:
            v = abs(lit)
            s = 1 if lit > 0 else -1
            counts.setdefault(v, set()).add(s)
    pure = sum(1 for v, ss in counts.items() if len(ss)==1)
    frac_pure = pure / max(1, nvars)
    return dict(alpha=alpha, mean_k=mean_k, frac_unit=frac_unit, frac_pure=frac_pure)

def seed_from_file(path):
    h = hashlib.sha256(Path(path).read_bytes()).hexdigest()
    return int(h[:8], 16)

def intents_from_metrics(T, m):
    # Negative pulses (creator will) suppress leakage x(t); tied to metrics
    pulses = []
    A1 = -0.5 * (0.2 + 0.8*m["frac_pure"])         # purity -> early stabilization
    pulses.append((0.25*T, 0.30*T, A1))
    A2 = -0.6 * (0.2 + 1.2*m["frac_unit"])         # unit clauses -> mid pulse
    pulses.append((0.55*T, 0.60*T, A2))
    A3 = -0.4 * min(2.0, max(0.0, (m["alpha"]-3.5))) # density beyond 3.5 -> late clamp
    pulses.append((0.82*T, 0.86*T, A3))
    return ",".join(f"{a:.6g}:{b:.6g}:{c:.6g}" for (a,b,c) in pulses)

def label_from_name(name):
    # Heuristic: 'uuf' indicates UNSAT dataset; 'uf' indicates SAT
    lname = name.lower()
    return "UNSAT" if "uuf" in lname else "SAT"

# ---------- Discover CNF files ----------
candidates = [
    "uf250-099.cnf",
    "uuf250-099.cnf",
    "uf250-0100.cnf",
    "uuf250-0100.cnf",
    "uuf250-0100.cnf",
    "uuf250-099.cnf",
    "uf250-0100.cnf",
]

cnf_files = [p for p in candidates if os.path.exists(p)]
# also include any other .cnf files the user might have uploaded
cnf_files += [p for p in glob.glob("*.cnf") if p not in cnf_files]

rows = []

for path in cnf_files:
    try:
        nvars, nclauses, clauses = parse_dimacs(path)
        m = cnf_metrics(nvars, nclauses, clauses)
        seed = seed_from_file(path)
        x0 = 0.003 + 0.004 * min(10.0, m["alpha"])
        T = 10.0
        N = 5000 if nclauses >= 5000 else 2000

        t = AO.make_time_grid(T, N)
        intent_spec = intents_from_metrics(T, m)
        intents = AO.parse_intent_spec(intent_spec)

        x_t, c_noise, c_intent = AO.build_source(t, x0, seed, intent=intents)
        core = AO.compute_core(t, x_t)

        # Chain rule (phase vector law) residual summary
        resid = core["transport_residual"]
        resid_max = float(np.max(np.abs(resid)))
        resid_l2 = float(np.sqrt(np.mean(resid**2)))

        prefix = f"./Results/AO_from_CNF__{Path(path).stem}"
        AO.save_csv(f"{prefix}.csv", t, x_t, core)
        AO.plot_series(t, x_t,      f"{Path(path).name}: x(t)", f"{prefix}__x_t.png", ylabel="x(t)")
        AO.plot_series(t, core["Psi_t"], f"{Path(path).name}: Ψ(t)", f"{prefix}__Psi_t.png", ylabel="Ψ(t)")
        AO.plot_series(t, core["transport_residual"], f"{Path(path).name}: transport residual", f"{prefix}__residual.png", ylabel="residual")

        rows.append({
            "file": Path(path).name,
            "label": label_from_name(path),
            "nvars": nvars,
            "nclauses": nclauses,
            "alpha": round(m["alpha"], 6),
            "mean_k": round(m["mean_k"], 3),
            "frac_unit": round(m["frac_unit"], 6),
            "frac_pure": round(m["frac_pure"], 6),
            "x0": round(x0, 6),
            "seed": seed,
            "M_T": core["M_t"][-1],
            "Psi_T": core["Psi_t"][-1],
            "resid_max": resid_max,
            "resid_l2": resid_l2,
            "csv": f"{prefix}.csv",
            "png_x": f"{prefix}__x_t.png",
            "png_psi": f"{prefix}__Psi_t.png",
            "png_res": f"{prefix}__residual.png",
            "intent_spec": intent_spec,
        })
    except Exception as e:
        rows.append({"file": Path(path).name, "error": repr(e)})

#df = pd.DataFrame(rows).sort_values(by=["label","file"]).reset_index(drop=True)
#display_dataframe_to_user("AO mapping from DIMACS CNF (with chain rule check)", df)

# Print quick summary
print("Processed CNF files:", len(cnf_files))
#print(df[["file","label","nvars","nclauses","alpha","resid_l2","csv","png_x","png_psi","png_res"]])

for row in rows:
    print(row)
